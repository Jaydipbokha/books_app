import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../viewmodels/book_viewmodel.dart';

class HomeView extends StatefulWidget {
  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final BookViewModel controller = Get.put(BookViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Books by Filter")),
      body: GetX<BookViewModel>(
        builder: (controller) {
          if (controller.isLoading.value) {
            return Center(child: CircularProgressIndicator());
          }

          return Column(
            children: [
              // Dropdown for selecting filter type
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButton<String>(
                  value: controller.selectedFilter.value,
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      controller.setFilter(newValue); // Update the filter
                    }
                  },
                  items: controller.filterOptions.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),

              // Button to open the bottom sheet
              ElevatedButton(
                onPressed: () {
                  _showFilterBottomSheet(context, controller);
                },
                child: Text("Open Filter Options"),
              ),

              // Display books based on selected filter
              Expanded(
                child: ListView(
                  children: controller.groupedBooks.entries.map((entry) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            entry.key,
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(
                          height: 120,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: entry.value.length,
                            itemBuilder: (context, index) {
                              final book = entry.value[index];
                              return Card(
                                margin: EdgeInsets.all(8),
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: NetworkImage(book.bookFrontImage ?? ''),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        book.bookNameEnglish ?? '',
                                        style: TextStyle(fontSize: 12, color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        book.authorData.isNotEmpty
                                            ? book.authorData[0].authorEnglish ?? ''
                                            : 'Unknown Author',
                                        style: TextStyle(fontSize: 10, color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // Bottom sheet to display filter options
  void _showFilterBottomSheet(BuildContext context, BookViewModel controller) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Makes the bottom sheet flexible with content size
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Topics Section
                _buildFilterSection(
                  title: "Topics",
                  items: controller.groupedBooks.keys
                      .where((topic) => topic != 'Unknown')
                      .toList(),
                  selectedItems: controller.selectedTopics,
                  onChanged: controller.updateSelectedTopic,
                ),

                // Authors Section
                _buildFilterSection(
                  title: "Authors",
                  items: controller.groupedBooks.keys
                      .where((author) => author != 'Unknown')
                      .toList(),
                  selectedItems: controller.selectedAuthors,
                  onChanged: controller.updateSelectedAuthor,
                ),

                // Languages Section
                _buildFilterSection(
                  title: "Languages",
                  items: controller.groupedBooks.keys
                      .where((language) => language != 'Unknown')
                      .toList(),
                  selectedItems: controller.selectedLanguages,
                  onChanged: controller.updateSelectedLanguage,
                ),

                // Apply Button
                Padding(
                  padding: const EdgeInsets.only(top: 16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      controller.applyFilters(); // Apply selected filters
                      Navigator.pop(context); // Close the bottom sheet
                    },
                    child: Text("Apply Filters"),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildFilterSection({
    required String title,
    required List<String> items,
    required RxSet<String> selectedItems,
    required Function(String) onChanged,
  }) {
    return ExpansionTile(
      title: Text(title),
      children: items.map((item) {
        return Obx(  // Make checkbox state reactive
          () => CheckboxListTile(
            title: Text(item),
            value: selectedItems.contains(item),
            onChanged: (bool? value) {
              if (value != null) {
                onChanged(item); // Update selected filter item
              }
            },
          ),
        );
      }).toList(),
    );
  }
}
